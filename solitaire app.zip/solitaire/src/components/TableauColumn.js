import React, { memo } from 'react';
import { View, TouchableOpacity, StyleSheet } from 'react-native';
import { CardFace, CardBack } from './CardFace';
import {
  CARD_WIDTH,
  CARD_HEIGHT,
  CARD_RADIUS,
  COLORS,
  FACE_DOWN_OVERLAP,
  FACE_UP_OVERLAP,
} from '../utils/constants';

const TableauColumn = memo(({
  cards,
  colIndex,
  onCardPress,
  hintedCardId,
  isDropTarget,
}) => {
  const colHeight = Math.max(
    CARD_HEIGHT,
    cards.reduce((h, card, i) => {
      if (i < cards.length - 1) {
        return h + (card.faceUp ? FACE_UP_OVERLAP : FACE_DOWN_OVERLAP);
      }
      return h + CARD_HEIGHT;
    }, 0)
  );

  return (
    <View style={[styles.column, { height: colHeight }, isDropTarget && styles.dropTarget]}>
      {cards.length === 0 && (
        <View style={styles.emptySlot} />
      )}
      {cards.map((card, idx) => {
        const top = cards.slice(0, idx).reduce((h, c) =>
          h + (c.faceUp ? FACE_UP_OVERLAP : FACE_DOWN_OVERLAP), 0
        );
        const isHinted = card.id === hintedCardId;
        const isTopCard = idx === cards.length - 1;

        return (
          <TouchableOpacity
            key={card.id}
            activeOpacity={card.faceUp ? 0.82 : 1}
            onPress={() => card.faceUp && onCardPress(colIndex, idx)}
            style={[styles.cardWrapper, { top, zIndex: idx + 1 }]}
          >
            {card.faceUp
              ? <CardFace card={card} isHinted={isHinted} />
              : <CardBack />
            }
          </TouchableOpacity>
        );
      })}
    </View>
  );
});

export default TableauColumn;

const styles = StyleSheet.create({
  column: {
    width: CARD_WIDTH,
    position: 'relative',
  },
  cardWrapper: {
    position: 'absolute',
    width: CARD_WIDTH,
    height: CARD_HEIGHT,
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.22,
    shadowRadius: 3,
    elevation: 3,
  },
  emptySlot: {
    width: CARD_WIDTH,
    height: CARD_HEIGHT,
    borderRadius: CARD_RADIUS,
    borderWidth: 1.5,
    borderColor: COLORS.emptyBorder,
    borderStyle: 'dashed',
    backgroundColor: COLORS.emptySlot,
  },
  dropTarget: {
    borderRadius: CARD_RADIUS + 2,
    shadowColor: COLORS.gold,
    shadowOpacity: 0.9,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
    elevation: 12,
  },
});
