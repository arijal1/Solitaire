import React, { memo } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { CardFace } from './CardFace';
import { CARD_WIDTH, CARD_HEIGHT, CARD_RADIUS, FONT } from '../utils/constants';
import { useTheme } from '../theme/ThemeContext';

const SUIT_LABELS = ['♠','♣','♥','♦'];

const Foundation = memo(({ foundations, onFoundationPress, dropHighlightIndex }) => {
  const t = useTheme();
  return (
    <View style={styles.row}>
      {foundations.map((pile, i) => {
        const topCard = pile.length > 0 ? pile[pile.length - 1] : null;
        const isHL = dropHighlightIndex === i;
        return (
          <TouchableOpacity
            key={i}
            activeOpacity={0.85}
            onPress={() => topCard && onFoundationPress?.(i)}
            style={[styles.slot, isHL && { shadowColor: t.gold, shadowOpacity: 1, shadowRadius: 14, elevation: 10 }]}
          >
            {topCard
              ? <CardFace card={topCard} isHinted={false} />
              : <View style={[styles.empty, { backgroundColor: t.emptySlot, borderColor: t.emptyBorder }]}>
                  <Text style={[styles.label, { color: t.textSecondary }]}>{SUIT_LABELS[i]}</Text>
                </View>
            }
          </TouchableOpacity>
        );
      })}
    </View>
  );
});

export default Foundation;

const styles = StyleSheet.create({
  row:  { flexDirection: 'row', gap: 3 },
  slot: {
    width: CARD_WIDTH, height: CARD_HEIGHT,
    borderRadius: CARD_RADIUS, overflow: 'hidden',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.28, shadowRadius: 3, elevation: 3,
  },
  empty: {
    flex: 1, borderRadius: CARD_RADIUS,
    borderWidth: 1.5, borderStyle: 'dashed',
    justifyContent: 'center', alignItems: 'center',
  },
  label: { fontSize: FONT.bigSuitSize * 0.85, opacity: 0.6 },
});
