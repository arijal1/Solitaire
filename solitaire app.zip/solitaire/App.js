import React from 'react';
import { ThemeProvider } from './src/theme/ThemeContext';
import ThemedRoot        from './src/theme/ThemedRoot';
import GameScreen        from './src/components/GameScreen';

export default function App() {
  return (
    <ThemeProvider>
      <ThemedRoot>
        <GameScreen />
      </ThemedRoot>
    </ThemeProvider>
  );
}
